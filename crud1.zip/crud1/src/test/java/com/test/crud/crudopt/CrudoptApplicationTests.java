 package com.test.crud.crudopt;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.test.crud.crudopt.entity.BookHar;
import com.test.crud.crudopt.respository.BooksRepository;
import com.test.crud.crudopt.service.BookService;

@RunWith(SpringRunner.class)
@SpringBootTest
class CrudoptApplicationTests {

	@Autowired
	private BookService bookService;

	@MockBean
	BooksRepository booksRepository;

	@Test
	 void getBookTest() {
		when(booksRepository.findAll()).thenReturn(
		Stream.of(new BookHar(101L, "harshit", "Singh", 101L), new BookHar(20L, "harshit1", "Singh1", 101202L))
		.collect(Collectors.toList()));
		assertEquals(2, bookService.getAllBooks().size());
	}

	 @Test
	  void getBookByidTest() {
		 BookHar bookhar = new BookHar(999L, "Mahabharat", "balmiki", 1500L);
		 when(booksRepository.findById(999L)).thenReturn(Optional.of(bookhar));
		 System.out.println(bookService.getBooksById(999L));
		 assertEquals(bookhar, bookService.getBooksById(999L));
	  }
 
	@Test
	 void saveBookTest() { 
		BookHar bookhar = new BookHar(999L, "Mahabharat", "balmiki", 1500L);
		when(booksRepository.save(bookhar)).thenReturn(bookhar);
		assertEquals(bookhar, bookService.saveOrUpdate(bookhar));
	}
	
	@Test
	 void UpdateBookTest() { 
		BookHar bookhar = new BookHar(999L, "Mahabharat", "balmiki", 1500L);
		System.out.println(bookhar);
		bookhar.setBookName("atomic habit");
		when(booksRepository.save(bookhar)).thenReturn(bookhar);
		BookHar updateBook = bookService.update(bookhar);
		// then - verify the output
		assertThat(updateBook).isNotNull();
		assertThat(updateBook.getBookName()).isEqualTo(bookhar.getBookName());
	}

	@Test
	 void deleteBookTest() {
		bookService.delete(999);
		verify(booksRepository, times(1)).deleteById((long) 999);
	}

}
