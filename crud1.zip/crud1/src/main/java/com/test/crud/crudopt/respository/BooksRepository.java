package com.test.crud.crudopt.respository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.test.crud.crudopt.entity.BookHar;
public interface BooksRepository extends CrudRepository<BookHar, Long>  {

	
}
