package com.test.crud.crudopt.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.crud.crudopt.entity.BookHar;
import com.test.crud.crudopt.respository.BooksRepository;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class BookService {

	@Autowired

	BooksRepository booksRepository;  

	//save book record
	public BookHar saveOrUpdate(BookHar bookhar){  
		booksRepository.save(bookhar);  
		log.info("save data");
		return bookhar;
		
	}  
	
	//get all book record
	public List<BookHar> getAllBooks(){  
		List<BookHar> books = new ArrayList<BookHar>();  
		booksRepository.findAll().forEach(books1 -> books.add(books1)); 
		log.info("get all book");

		return books;  
	}  
	
	//get by id
	public BookHar getBooksById(Long id){  	
		log.info("get book by id");

		return booksRepository.findById(id).get(); 

	}  
	 
	//delete by id
	public void delete(long id){  
		booksRepository.deleteById(id);  
	}  
	
	// update by id
	public BookHar update(BookHar bookhar){  
		return booksRepository.save(bookhar);  
	}  	
}
