package com.test.crud.crudopt.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.test.crud.crudopt.entity.BookHar;
import com.test.crud.crudopt.service.BookService;

@RestController
public class Controller {
	
	@Autowired
	BookService booksService;
	
	@GetMapping("/book")
	public String getAllBooks() {
		return "My first code";
	}

	@PostMapping("/saveBooks")
	public long saveBook(@RequestBody BookHar bookhar) {
		booksService.saveOrUpdate(bookhar);
		return bookhar.getBid();
	}

	@GetMapping("/getbook")
	public List<BookHar> getAlBooks() {
		return booksService.getAllBooks();
	}

	@GetMapping("/book/{bookid}")
	public BookHar getBooks(@PathVariable("bookid") long bookid) {
		return booksService.getBooksById((bookid));
	}

	@ExceptionHandler(NoSuchElementException.class)
	public String handleException(NoSuchElementException ex) {
		return "Oops! Id is wrong, no such id prresent in our db";
	}

	@DeleteMapping("/bookdel/{bookid}")
	public void deleteBook(@PathVariable("bookid") long bookid) {
		booksService.delete(bookid);
	}

	@ExceptionHandler(EmptyResultDataAccessException.class)
	public String handleException(EmptyResultDataAccessException ex) {
		return "Oops! Id is wrong, no such id prresent in our db";
	}

	@PutMapping("/Updatebooks")
	public BookHar update(@RequestBody BookHar bookhar) {
		booksService.saveOrUpdate(bookhar);
		return bookhar;
	}
}
