package com.test.crud.crudopt;

import java.lang.management.ManagementFactory;

public class ProcessHelper {
public static String getProcessId() {
	String name = ManagementFactory.getRuntimeMXBean().getName();
	if(name != null && name.contains("@")) {
		return name.split("@")[0];
	}
	return "UNKNOWN";
}
}
