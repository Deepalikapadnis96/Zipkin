package com.test.crud.crudopt;

import org.apache.logging.log4j.ThreadContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import brave.sampler.Sampler;
import lombok.extern.log4j.Log4j2;
@Log4j2
@SpringBootApplication
public class CrudoptApplication {

	public static void main(String[] args) {
        System.setProperty("spring.devtools.restart.enabled", "false");//Avoid Breakpoint at “throw new SilentExitException()” in Eclipse + Spring Boot

		System.setProperty("hostname", getHostName());
		System.setProperty("pid", ProcessHelper.getProcessId());
		String requestId = generateRequestId();
		long startTime = System.currentTimeMillis();
		log.info("start Time: {}", startTime);
 		SpringApplication.run(CrudoptApplication.class, args);

		// log-->>tags if we use slf4j used MDC/NDC on log4j2 use threadcontext
		ThreadContext.put("requestId", requestId);
		
		long endTime = System.currentTimeMillis();
		log.info("end Time:{}", endTime);

		long executionTime = endTime - startTime;
		log.info("execution Time: {} milisecond", executionTime);
		ThreadContext.remove(requestId);
        System.clearProperty("pid");

	}

	private static String getHostName() {
		try {
			return java.net.InetAddress.getLocalHost().getHostName();
		} catch (Exception e) {
			log.error("error occurs",e);
			return "UNKNOWN";
		}
	}

	private static String generateRequestId() {
		// System.out.println("-->>"+ java.util.UUID.randomUUID().toString());
		return java.util.UUID.randomUUID().toString();
	}
	@Bean
	public Sampler defaultSampler() {
		return Sampler.ALWAYS_SAMPLE;
	}
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

}
