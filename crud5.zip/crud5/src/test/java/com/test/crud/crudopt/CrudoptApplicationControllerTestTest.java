package com.test.crud.crudopt;

import static org.hamcrest.CoreMatchers.is;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.crud.crudopt.entity.BookHar;
import com.test.crud.crudopt.service.BookService;

@WebMvcTest
class CrudoptApplicationControllerTestTest {

	@Mock
	private ObjectMapper objectMapper;

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private BookService bookService;
	
	
	


	@Test
	void testGivenBookList_whenGetAllBook_thenReturnBookList() throws Exception {
		List<BookHar> bookhars = new ArrayList<>();
		BookHar bookhar1 = new BookHar(999L, "Mahabharat", "balmiki", 1500L);
		BookHar bookhar2 = new BookHar(110L, "atomic habits", "balmiki", 1500L);
		bookhars.add(bookhar1);
		bookhars.add(bookhar2);
		given(bookService.getAllBooks()).willReturn(bookhars);
		ResultActions response = mockMvc.perform(get("/getbook"));
		response.andDo(print())
		        .andExpect(status()
		        .isOk())
		        .andExpect(jsonPath("$.size()", is(bookhars.size())));
	}

	  @Test
	   void givenBookId_whenGetBookById_thenReturnBookObject() throws Exception {
		  // given - precondition or setup
		  BookHar bookhar = new BookHar(999L, "Mahabharat", "balmiki", new Long(1500));
		  given(bookService.getBooksById(999L)).willReturn(bookhar);
		  int bookPrice=Math.toIntExact(bookhar.getBookPrice()) ;
		  ResultActions response = mockMvc.perform(get("/book/{bid}", 999L));
	      response.andExpect(status().isOk()).andDo(print())
	      .andExpect(jsonPath("$.bookName", is(bookhar.getBookName())))
	      .andExpect(jsonPath("$.bookAuthName", is(bookhar.getBookAuthName())))
	      .andExpect(jsonPath("$.bookPrice", is(bookPrice)));
	  
	  }
}
